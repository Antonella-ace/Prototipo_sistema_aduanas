<?php

include 'conexion.php';

$patente = $_POST['patente'];
$modelo = $_POST['modelo'];
$anio = $_POST['anio'];
$pais = $_POST['pais'];

$sql = "INSERT INTO vehiculos (patente, modelo, anio, pais)
VALUES ('$patente', '$modelo', '$anio', '$pais')";

if ($conn->query($sql) === TRUE) {
    echo "Vehículo registrado correctamente";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();

?>