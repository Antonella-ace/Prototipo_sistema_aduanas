<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "sigf_aduanas";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

?>