<?php

include "conexion.php";

$data = [];

// Total vehículos
$sql = "SELECT COUNT(*) AS total FROM vehiculos";
$resultado = $conn->query($sql);
$data["vehiculos"] = $resultado->fetch_assoc()["total"];


// Total declaraciones SAG
$sql = "SELECT COUNT(*) AS total FROM declaraciones_sag";
$resultado = $conn->query($sql);
$data["sag"] = $resultado->fetch_assoc()["total"];


// Total mascotas
$sql = "SELECT COUNT(*) AS total FROM mascotas";
$resultado = $conn->query($sql);
$data["mascotas"] = $resultado->fetch_assoc()["total"];


// Total menores
$sql = "SELECT COUNT(*) AS total FROM menores";
$resultado = $conn->query($sql);
$data["menores"] = $resultado->fetch_assoc()["total"];


header("Content-Type: application/json");

echo json_encode($data);

$conn->close();

?>