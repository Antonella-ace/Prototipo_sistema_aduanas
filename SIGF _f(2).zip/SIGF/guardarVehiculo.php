<?php

include "conexion.php";

$patente = $_POST['patente'] ?? '';
$modelo = $_POST['modelo'] ?? '';
$anio = $_POST['anio'] ?? '';
$pais = $_POST['pais'] ?? '';

if(empty($patente)){
    echo "Error: falta patente";
    exit;
}

$sql = "INSERT INTO vehiculos
(patente, modelo, anio, pais)
VALUES
('$patente','$modelo','$anio','$pais')";


if($conn->query($sql)){

    echo "Vehículo registrado correctamente";

}else{

    echo "Error SQL: " . $conn->error;

}


$conn->close();

?>