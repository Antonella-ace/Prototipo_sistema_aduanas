<?php

include 'conexion.php';

$rut = $_POST['rut'];
$nombre = $_POST['nombre'];
$autorizacion = $_POST['autorizacion'];

$sql = "INSERT INTO menores
(rut_menor,nombre,autorizacion)
VALUES
('$rut','$nombre','$autorizacion')";

if($conn->query($sql)){
    echo "Menor registrado";
}else{
    echo "Error: " . $conn->error;
}

$conn->close();

?>