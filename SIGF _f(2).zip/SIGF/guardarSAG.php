<?php

include 'conexion.php';

$productos = $_POST['productos'];
$descripcion = $_POST['descripcion'];

$sql = "INSERT INTO declaraciones_sag
(productos, descripcion)
VALUES
('$productos','$descripcion')";

if($conn->query($sql)){
    echo "Declaración SAG registrada";
}else{
    echo "Error: " . $conn->error;
}

$conn->close();

?>