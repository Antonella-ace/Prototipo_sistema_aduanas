<?php

include "conexion.php";

$sql = "SELECT * FROM registros ORDER BY id DESC";

$resultado = $conn->query($sql);

$registros = [];

if ($resultado) {

    while ($fila = $resultado->fetch_assoc()) {

        $registros[] = $fila;

    }

}

header("Content-Type: application/json");

echo json_encode($registros);

$conn->close();

?>