-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-07-2026 a las 02:18:50
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sigf_aduanas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `declaraciones_sag`
--

CREATE TABLE `declaraciones_sag` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `productos` varchar(255) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `declaraciones_sag`
--

INSERT INTO `declaraciones_sag` (`id`, `usuario_id`, `productos`, `descripcion`, `fecha_registro`) VALUES
(1, NULL, '', '', '2026-06-11 01:57:39'),
(2, NULL, 'Sí', 'verduras', '2026-06-11 02:13:49'),
(3, NULL, 'Sí', 'frutas', '2026-06-24 23:58:30'),
(6, NULL, 'Sí', 'paltas', '2026-07-13 01:02:06'),
(7, NULL, 'No', '', '2026-07-13 03:22:48'),
(8, NULL, 'No', '', '2026-07-13 03:44:41'),
(9, NULL, 'No', '', '2026-07-13 04:11:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascotas`
--

CREATE TABLE `mascotas` (
  `id` int(11) NOT NULL,
  `microchip` varchar(50) NOT NULL,
  `raza` varchar(100) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mascotas`
--

INSERT INTO `mascotas` (`id`, `microchip`, `raza`, `fecha_registro`) VALUES
(1, '123456789', 'Labrador', '2026-06-11 02:13:15'),
(2, '23424343', 'Labrador', '2026-06-18 00:44:09'),
(3, '12354678-5', 'Golden', '2026-06-30 21:32:37'),
(4, '4567', 'Chiguagua', '2026-07-02 00:41:03'),
(5, '4567', 'Golden', '2026-07-13 00:35:04'),
(6, '4567', 'Golden', '2026-07-13 00:35:13'),
(7, '4567', 'Golden', '2026-07-13 00:56:46'),
(8, '4567', 'Labrador', '2026-07-13 03:10:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menores`
--

CREATE TABLE `menores` (
  `id` int(11) NOT NULL,
  `rut_menor` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `autorizacion` varchar(100) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `menores`
--

INSERT INTO `menores` (`id`, `rut_menor`, `nombre`, `autorizacion`, `fecha_registro`) VALUES
(1, '13776254-5', 'marta silva', 'Autorización notarial', '2026-06-18 00:10:30'),
(2, '34567234-0', 'aquiles sanchez', 'Autorización notarial', '2026-06-18 00:37:51'),
(3, '34567234-0', 'aquiles sanchez', 'Autorización notarial', '2026-06-18 00:39:02'),
(4, '23435536-9', 'miguel cornejo', 'Autorización notarial', '2026-06-25 00:25:04'),
(5, '12345678-0', 'marcos solis', 'Autorización notarial', '2026-07-13 01:16:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros`
--

CREATE TABLE `registros` (
  `id` int(11) NOT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `detalle` text DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `qr` varchar(100) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `registros`
--

INSERT INTO `registros` (`id`, `tipo`, `detalle`, `usuario`, `qr`, `fecha_registro`) VALUES
(1, '', '', '', '', '2026-06-18 00:45:06'),
(2, 'Declaración SAG', 'Productos: paltas - Declaración SAG', 'funcionario', 'SAG-1783904528313', '2026-07-13 01:02:08'),
(3, 'Admisión Vehículo', 'Patente ABCD12, Toyota, Argentina - Admisión 180 días', 'funcionario', 'VEH-1783904896463', '2026-07-13 01:08:16'),
(4, 'Autorización Menor', 'RUT 12345678-0, marcos solis, Autorización notarial', 'funcionario', 'MEN-1783905394125', '2026-07-13 01:16:34'),
(5, 'Registro Mascota', 'Microchip 4567, Raza: Labrador', 'funcionario', 'PET-1783912224562', '2026-07-13 03:10:24'),
(6, 'Declaración SAG', 'Productos: Ninguno - Declaración SAG', 'funcionario', 'SAG-1783912970660', '2026-07-13 03:22:50'),
(7, 'Declaración SAG', 'Productos: Ninguno - Declaración SAG', 'funcionario', 'SAG-1783914282256', '2026-07-13 03:44:42'),
(8, 'Admisión Vehículo', 'Patente ZH8909, CHEVROLET, Argentina - Admisión 180 días', 'funcionario', 'VEH-1783914320528', '2026-07-13 03:45:20'),
(9, 'Declaración SAG', 'Productos: Ninguno - Declaración SAG', 'funcionario', 'SAG-1783915877122', '2026-07-13 04:11:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `rut` varchar(15) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `rut`, `nombre`, `password`, `rol`) VALUES
(1, '12345678-9', 'Funcionario Aduanas', 'admin123', 'Funcionario Aduanas'),
(2, '22222222-2', 'Funcionario SAG/PDI', 'sag2026', 'Funcionario SAG/PDI'),
(3, '99999999-9', 'Administrador SIGF', 'admin2026', 'Administrador SIGF');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `id` int(11) NOT NULL,
  `patente` varchar(20) NOT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `pais` varchar(50) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`id`, `patente`, `modelo`, `anio`, `pais`, `fecha_registro`) VALUES
(1, '', '', 0, '', '2026-06-11 01:25:24'),
(2, 'ABCD12', 'Toyota', 2024, 'Chile', '2026-06-11 01:40:21'),
(5, '', '', 0, '', '2026-07-13 00:55:46'),
(6, 'ABCD12', 'Toyota', 2024, 'Argentina', '2026-07-13 01:08:12'),
(7, 'ABCD12', 'Toyota', 2024, 'Argentina', '2026-07-13 03:29:15'),
(8, 'ABCD12', 'Toyota', 2024, 'Argentina', '2026-07-13 03:29:27'),
(9, 'ABCD12', 'Toyota', 2024, 'Argentina', '2026-07-13 03:31:41'),
(10, 'ABCD12', 'Toyota', 2024, 'Argentina', '2026-07-13 03:33:01'),
(11, 'ABCD12', 'Toyota', 2024, 'Argentina', '2026-07-13 03:44:04'),
(12, 'ZH8909', 'CHEVROLET', 2007, 'Argentina', '2026-07-13 03:45:19');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `declaraciones_sag`
--
ALTER TABLE `declaraciones_sag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `mascotas`
--
ALTER TABLE `mascotas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menores`
--
ALTER TABLE `menores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rut` (`rut`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `declaraciones_sag`
--
ALTER TABLE `declaraciones_sag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `mascotas`
--
ALTER TABLE `mascotas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `menores`
--
ALTER TABLE `menores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `registros`
--
ALTER TABLE `registros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `declaraciones_sag`
--
ALTER TABLE `declaraciones_sag`
  ADD CONSTRAINT `declaraciones_sag_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
