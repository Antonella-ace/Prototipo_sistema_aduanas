<?php

include 'conexion.php';

$microchip = $_POST['microchip'];
$raza = $_POST['raza'];

$sql = "INSERT INTO mascotas
(microchip, raza)
VALUES
('$microchip','$raza')";

if($conn->query($sql)){
    echo "Mascota registrada";
}else{
    echo "Error: " . $conn->error;
}

$conn->close();

?>