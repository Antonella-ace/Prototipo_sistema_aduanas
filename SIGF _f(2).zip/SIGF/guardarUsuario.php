<?php

include 'conexion.php';

$rut = $_POST['rut'];
$nombre = $_POST['nombre'];
$password = $_POST['password'];
$rol = $_POST['rol'];

$sql = "INSERT INTO usuarios
(rut,nombre,password,rol)
VALUES
('$rut','$nombre','$password','$rol')";

if($conn->query($sql)){
    echo "Usuario registrado";
}else{
    echo "Error: " . $conn->error;
}

$conn->close();

?>