<?php

include 'conexion.php';

$tipo = $_POST['tipo'];
$detalle = $_POST['detalle'];
$usuario = $_POST['usuario'];
$qr = $_POST['qr'];

$sql = "INSERT INTO registros
(tipo,detalle,usuario,qr)
VALUES
('$tipo','$detalle','$usuario','$qr')";

if($conn->query($sql)){
    echo "Registro almacenado";
}else{
    echo "Error: " . $conn->error;
}

$conn->close();

?>