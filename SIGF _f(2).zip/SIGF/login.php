<?php

include 'conexion.php';

$rut = $_POST['rut'];
$password = $_POST['password'];

$sql = "SELECT * FROM usuarios
WHERE rut='$rut' AND password='$password'";

$resultado = $conn->query($sql);

if($resultado->num_rows > 0){

    $fila = $resultado->fetch_assoc();

    echo json_encode([
        "success" => true,
        "nombre" => $fila['nombre'],
        "rol" => $fila['rol']
    ]);

}else{

    echo json_encode([
        "success" => false
    ]);

}

$conn->close();

?>